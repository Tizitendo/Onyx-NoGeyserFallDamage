# Onyx-NoGeyserFallDamage

- Removes fall damage taken after using a geyser
- Gives players higher control over when to use geysers by only enabling them while the jump button is pressed (can be toggled off)
- falling on a geyser still removes fall damage

## Special Thanks To
* The Return Of Modding Discord

## Contact
For questions or bug reports, you can find us in the [RoRR Modding Server](https://discord.gg/VjS57cszMq) @Onyx
