## 1.2.0
* you now have to press jump to use geysers (can be toggled off)
* falling on a geyser still removes fall damage